<?php
class ControllerExtensionModuleFeedbackformModule extends Controller {

    private $error = array();
  
    public function index() {

        $this->load->language('extension/module/feedbackform_module');

		$this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');
        
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('module_feedbackform_module', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
		}
        
        if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}


        $data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);
		
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/feedbackform_module', 'user_token=' . $this->session->data['user_token'], true)
		);
		
		$data['action'] = $this->url->link('extension/module/feedbackform_module', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
		
        if (isset($this->request->post['module_feedbackform_module_status'])) {
			$data['module_feedbackform_module_status'] = $this->request->post['module_feedbackform_module_status'];
		} else {
			$data['module_feedbackform_module_status'] = $this->config->get('module_feedbackform_module_status');
		}

		$data['visitors'] = array();

		$this->load->model('extension/module/feedbackform_module');

		$results = $this->model_extension_module_feedbackform_module->getVisitors();

		foreach ($results as $result) {
			$data['visitors'][] = array(
				'visitor_id'    => $result['visitor_id'],
				'name'   => $result['name'],
				'phone'   => $result['phone'],
				'email'   => $result['email'],
				'page'   => $result['page'],
				'text'   => $result['text'],
				'created_at' => date($this->language->get('date_format_short'), strtotime($result['created_at'])),
			);
		}

        $data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/module/feedbackform_module', $data));

    }

    protected function validate() {

        if (!$this->user->hasPermission('modify', 'extension/module/feedbackform_module')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}


		return !$this->error;

    }

	public function install() {

		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "visitor` (`visitor_id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , `email` VARCHAR(96) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , `phone` VARCHAR(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , `text` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , `page` VARCHAR(96) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , `created_at` TIMESTAMP NOT NULL , PRIMARY KEY (`visitor_id`))");

	}

}