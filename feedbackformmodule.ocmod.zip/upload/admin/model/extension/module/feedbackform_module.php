<?php
class ModelExtensionModuleFeedbackformModule extends Model {

	public function getVisitors($data = array()) {
		$sql = "SELECT * FROM `" . DB_PREFIX . "visitor`";

		$query = $this->db->query($sql);

		return $query->rows;
	}

}