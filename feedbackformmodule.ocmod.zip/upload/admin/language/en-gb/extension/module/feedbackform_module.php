<?php
// Heading
$_['heading_title']     = 'Feedbackform Module';

// Text
$_['text_list']     = 'Feedbacks by visitors';
$_['text_extension']    = 'Extensions';
$_['text_success']      = 'Success: You have modified module!';
$_['column_name']         = 'Name';
$_['column_email']         = 'Email';
$_['column_phone']         = 'Phone';
$_['column_text']         = 'Text';
$_['column_date']         = 'Date';
$_['column_page']         = 'from Page';

// Entry
$_['entry_name']        = 'Module Name';
$_['entry_status']      = 'Status';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify this module!';
$_['error_name']        = 'Module Name must be between 3 and 64 characters!';


